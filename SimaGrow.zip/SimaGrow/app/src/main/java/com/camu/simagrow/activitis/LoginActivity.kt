package com.camu.simagrow.activitis

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.camu.simagrow.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        /*ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }*/

        /* =================================
        *      BOTON INICIAR SESION
        ====================================*/

        binding.btnIniciarSesion.setOnClickListener {
            var loginCorrecto : Boolean = false
            val niaIntroducido = binding.etNia.text.toString().trim()
            val passwordIntroducido = binding.etPassword.text.toString().trim()

            if (niaIntroducido.isEmpty() && passwordIntroducido.isEmpty()){
                Toast.makeText(this, "NIA o Contraseña en blanco", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val niaRegistrado = intent.getStringExtra("NIA")
            val passwordRegistrado = intent.getStringExtra("PASSWORD")

            var irMain = Intent(this, MainActivity::class.java)

            if (niaIntroducido == niaRegistrado  && passwordIntroducido == passwordRegistrado){
                loginCorrecto = true
            } else {
                Toast.makeText(this, "Los camopos son incorrectos", Toast.LENGTH_SHORT).show()
            }

            // Lazamos la activisolo si el login es valido
            if (loginCorrecto){
                startActivity(irMain)
            } else {
                Toast.makeText(this, "Campos obligatorios", Toast.LENGTH_SHORT).show()
            }
        }


        /* =================================
        *      BOTON CREAR CUENTA
        ====================================*/
        binding.btnCrearCuenta.setOnClickListener {
            val irMain = Intent(this, RegistreActivity::class.java).apply {

            }

            startActivity(irMain)
        }

    }


}