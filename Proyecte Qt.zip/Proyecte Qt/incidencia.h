#ifndef INCIDENCIA_H
#define INCIDENCIA_H
#include <QString>

struct Incidencia {
    int id;
    QString titulo;
    QString descripcion;
    QString estado;
};
#endif
