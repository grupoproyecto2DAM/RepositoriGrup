#!/bin/bash
# --- CONFIGURACIÓN ---
NOMBRE_FINAL="proyecto"
ARCHIVO_PRO="configuracion.pro"

echo "--- Preparando $NOMBRE_FINAL ---"

# 1. Crear el .pro solo si no existe
if [ ! -f "$ARCHIVO_PRO" ]; then
    qmake -project -o "$ARCHIVO_PRO"
    # Forzamos el nombre del ejecutable dentro del .pro
    echo "TARGET = $NOMBRE_FINAL" >> "$ARCHIVO_PRO"
    echo "QT += widgets" >> "$ARCHIVO_PRO"
    echo "Archivo $ARCHIVO_PRO configurado."
fi

# 2. Compilar y ejecutar en cadena
# qmake genera el Makefile, make compila, y luego ejecutamos
qmake "$ARCHIVO_PRO" && make -j$(nproc) && ./$NOMBRE_FINAL

# 3. Limpieza (Opcional: borra los archivos intermedios para dejar la carpeta limpia)
# rm -f *.o moc_*.cpp Makefile
