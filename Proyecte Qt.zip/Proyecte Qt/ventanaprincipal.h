#ifndef VENTANAPRINCIPAL_H
#define VENTANAPRINCIPAL_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QMessageBox>
#include <QFrame>
#include <QTableWidget>
#include <QHeaderView>
#include <QRegularExpression>

class VentanaPrincipal : public QMainWindow {
    Q_OBJECT

public:
    VentanaPrincipal(QWidget *parent = nullptr);

private slots:
    void login();
    void registrarUsuario();
    void irARegistro();
    void irALogin();
    void crearIncidencia(); // Nueva slot para la lógica de la tabla

private:
    QWidget* crearContenedorCentrado(QWidget* tarjeta);

    QStackedWidget *stackedWidget;

    // Campos Login/Registro
    QLineEdit *le_login_nia;
    QLineEdit *le_login_pass;
    QLineEdit *le_reg_nia;
    QLineEdit *le_reg_nombre;
    QLineEdit *le_reg_pass;
    QLineEdit *le_reg_pass_confirm;

    // Campos Incidencias (en Home)
    QLineEdit *le_inc_titulo;
    QLineEdit *le_inc_desc;
    QTableWidget *tablaIncidencias;

    // Vistas
    QWidget *crearVistaLogin();
    QWidget *crearVistaRegistro();
    QWidget *crearVistaHome(); // Aquí irá la tabla
};

#endif
