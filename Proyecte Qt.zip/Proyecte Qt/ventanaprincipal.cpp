#include "ventanaprincipal.h"
#include "vistaincidencias.h" // Importante incluir la nueva clase
#include "incidencia.h"

VentanaPrincipal::VentanaPrincipal(QWidget *parent) : QMainWindow(parent) {
    this->setWindowTitle("SimaGrow - Gestión de Incidencias");
    this->setMinimumSize(900, 700);

    stackedWidget = new QStackedWidget(this);

    stackedWidget->addWidget(crearVistaLogin());    // Index 0
    stackedWidget->addWidget(crearVistaRegistro()); // Index 1
    stackedWidget->addWidget(crearVistaHome());     // Index 2

    setCentralWidget(stackedWidget);

    this->setStyleSheet(
        "QMainWindow { border-image: url('./Imagenes/fondo.png') 0 0 0 0 stretch stretch; }"
        "QFrame#contenedorBlanco { background-color: rgba(255, 255, 255, 240); border-radius: 20px; border: 1px solid #ffffff; }"
        "QLineEdit { padding: 10px; border: 1px solid #ccc; border-radius: 8px; background: white; }"
        "QPushButton#btnPrincipal { background-color: #2ecc71; color: white; border-radius: 8px; padding: 12px; font-weight: bold; }"
        "QPushButton#btnPrincipal:hover { background-color: #27ae60; }"
        "QPushButton#btnPlano { color: #2ecc71; border: none; background: transparent; text-decoration: underline; font-weight: bold; }"
        "QTableWidget { background: white; gridline-color: #eee; border-radius: 5px; }"
    );
}

QWidget* VentanaPrincipal::crearContenedorCentrado(QWidget* tarjeta) {
    QWidget *pagina = new QWidget();
    QVBoxLayout *vLayout = new QVBoxLayout(pagina);
    QHBoxLayout *hLayout = new QHBoxLayout();
    hLayout->addStretch(1); hLayout->addWidget(tarjeta); hLayout->addStretch(1);
    vLayout->addStretch(1); vLayout->addLayout(hLayout); vLayout->addStretch(1);
    return pagina;
}

QWidget* VentanaPrincipal::crearVistaLogin() {
    QFrame *card = new QFrame();
    card->setObjectName("contenedorBlanco");
    card->setFixedWidth(360);
    QVBoxLayout *layout = new QVBoxLayout(card);
    layout->setContentsMargins(30,30,30,30); layout->setSpacing(15);

    QLabel *logo = new QLabel("<h1 style='color: #2ecc71;'>SIMAGROW</h1><p>Introduce tu NIA</p>");
    logo->setAlignment(Qt::AlignCenter);

    le_login_nia = new QLineEdit(); le_login_nia->setPlaceholderText("NIA");
    le_login_pass = new QLineEdit(); le_login_pass->setPlaceholderText("Contraseña");
    le_login_pass->setEchoMode(QLineEdit::Password);

    QPushButton *btn = new QPushButton("ENTRAR"); btn->setObjectName("btnPrincipal");
    QPushButton *reg = new QPushButton("¿No tienes cuenta? Regístrate"); reg->setObjectName("btnPlano");

    layout->addWidget(logo); layout->addWidget(le_login_nia); layout->addWidget(le_login_pass);
    layout->addWidget(btn); layout->addWidget(reg);

    connect(btn, &QPushButton::clicked, this, &VentanaPrincipal::login);
    connect(reg, &QPushButton::clicked, this, &VentanaPrincipal::irARegistro);

    return crearContenedorCentrado(card);
}

QWidget* VentanaPrincipal::crearVistaRegistro() {
    QFrame *card = new QFrame();
    card->setObjectName("contenedorBlanco");
    card->setFixedWidth(380);
    QVBoxLayout *layout = new QVBoxLayout(card);
    layout->setContentsMargins(30,30,30,30); layout->setSpacing(15);

    QLabel *logo = new QLabel("<h1 style='color: #2ecc71;'>SIMAGROW</h1><p>Registro de Usuario</p>");
    logo->setAlignment(Qt::AlignCenter);

    le_reg_nombre = new QLineEdit(); le_reg_nombre->setPlaceholderText("Nombre Completo");
    le_reg_nia = new QLineEdit(); le_reg_nia->setPlaceholderText("Tu NIA (8 números)");

    le_reg_pass = new QLineEdit();
    le_reg_pass->setPlaceholderText("Contraseña");
    le_reg_pass->setEchoMode(QLineEdit::Password);

    // NUEVO: Confirmar contraseña
    le_reg_pass_confirm = new QLineEdit();
    le_reg_pass_confirm->setPlaceholderText("Confirmar Contraseña");
    le_reg_pass_confirm->setEchoMode(QLineEdit::Password);

    QPushButton *btn = new QPushButton("REGISTRARSE"); btn->setObjectName("btnPrincipal");
    QPushButton *back = new QPushButton("Volver al Login"); back->setObjectName("btnPlano");

    layout->addWidget(logo);
    layout->addWidget(le_reg_nombre);
    layout->addWidget(le_reg_nia);
    layout->addWidget(le_reg_pass);
    layout->addWidget(le_reg_pass_confirm); // Añadido al layout
    layout->addWidget(btn);
    layout->addWidget(back);

    connect(btn, &QPushButton::clicked, this, &VentanaPrincipal::registrarUsuario);
    connect(back, &QPushButton::clicked, this, &VentanaPrincipal::irALogin);

    return crearContenedorCentrado(card);
}

void VentanaPrincipal::registrarUsuario() {
    QString nombre = le_reg_nombre->text().trimmed();
    QString nia = le_reg_nia->text().trimmed();
    QString pass = le_reg_pass->text();
    QString passConfirm = le_reg_pass_confirm->text();

    // 1. Validar nombre (mínimo 3 letras)
    if (nombre.length() < 3) {
        QMessageBox::warning(this, "Registro", "El nombre debe tener al menos 3 caracteres.");
        return;
    }

    // 2. Validar NIA (Regex: exactamente 8 números)
    QRegularExpression niaRegex("^[0-9]{8}$");
    if (!niaRegex.match(nia).hasMatch()) {
        QMessageBox::warning(this, "Registro", "El NIA debe consistir en exactamente 8 números.");
        return;
    }

    // 3. Validar contraseñas vacías
    if (pass.isEmpty()) {
        QMessageBox::warning(this, "Registro", "La contraseña no puede estar vacía.");
        return;
    }

    // 4. Confirmar que las contraseñas sean iguales
    if (pass != passConfirm) {
        QMessageBox::warning(this, "Registro", "Las contraseñas no coinciden.");
        return;
    }

    // Si todo está bien, procedemos
    QMessageBox::information(this, "SimaGrow", "¡Registro validado con éxito!");
    irALogin();
}

QWidget* VentanaPrincipal::crearVistaHome() {
    QFrame *card = new QFrame();
    card->setObjectName("contenedorBlanco");
    card->setMinimumWidth(800); // Responsive: se adapta al ancho
    QVBoxLayout *layout = new QVBoxLayout(card);
    layout->setContentsMargins(30,30,30,30);

    layout->addWidget(new QLabel("<h2>Gestión de Incidencias</h2>"));

    // Formulario Alta Incidencia
    QHBoxLayout *form = new QHBoxLayout();
    le_inc_titulo = new QLineEdit(); le_inc_titulo->setPlaceholderText("Título incidencia...");
    le_inc_desc = new QLineEdit(); le_inc_desc->setPlaceholderText("Descripción...");
    QPushButton *btnAlta = new QPushButton("ALTA"); btnAlta->setObjectName("btnPrincipal");
    btnAlta->setFixedWidth(100);

    form->addWidget(le_inc_titulo); form->addWidget(le_inc_desc); form->addWidget(btnAlta);
    layout->addLayout(form);

    // Tabla
    tablaIncidencias = new QTableWidget(0, 3);
    tablaIncidencias->setHorizontalHeaderLabels({"ID", "Título", "Estado"});
    tablaIncidencias->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    layout->addWidget(tablaIncidencias);

    QPushButton *logout = new QPushButton("Cerrar Sesión"); logout->setObjectName("btnPlano");
    layout->addWidget(logout, 0, Qt::AlignRight);

    connect(btnAlta, &QPushButton::clicked, this, &VentanaPrincipal::crearIncidencia);
    connect(logout, &QPushButton::clicked, this, &VentanaPrincipal::irALogin);

    return crearContenedorCentrado(card);
}

void VentanaPrincipal::crearIncidencia() {
    if(le_inc_titulo->text().isEmpty()) return;
    int row = tablaIncidencias->rowCount();
    tablaIncidencias->insertRow(row);
    tablaIncidencias->setItem(row, 0, new QTableWidgetItem(QString::number(row + 1)));
    tablaIncidencias->setItem(row, 1, new QTableWidgetItem(le_inc_titulo->text()));
    tablaIncidencias->setItem(row, 2, new QTableWidgetItem("Pendiente"));
    le_inc_titulo->clear(); le_inc_desc->clear();
}

void VentanaPrincipal::login() {
    if(le_login_nia->text().isEmpty()) QMessageBox::warning(this, "SimaGrow", "Introduce tu NIA");
    else stackedWidget->setCurrentIndex(2);
}

void VentanaPrincipal::irARegistro() { stackedWidget->setCurrentIndex(1); }
void VentanaPrincipal::irALogin() { stackedWidget->setCurrentIndex(0); }
